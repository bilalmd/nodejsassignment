var request = require('request');
exports.executeSearchReq = function(searchRequest, callback){
	request({
			uri:"http://192.168.3.131:9091/bundledapp/search",
			method:"POST",
			headers:{"content-type":"application/json"},
			timeout:180000,
			body:searchRequest
	},function(error, response, body){
		if(error)
		{
			console.error(error)
		}else{
			callback(null,body);
		}	
	});
}
exports.checkAvailability = function(availabilityRequest, callback){
	request({
			uri:"http://192.168.3.131:9091/bundledapp/availability",
			method:"POST",
			headers:{"content-type":"application/json"},
			timeout:180000,
			body:availabilityRequest
	},function(error, response, body){
		if(error)
		{
			console.error(error)
		}else{
			callback(null,body);
		}	
	});
} 