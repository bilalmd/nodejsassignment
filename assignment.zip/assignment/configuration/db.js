var mongoose = require("mongoose");
var MongoClient = require('mongodb').MongoClient,
assert = require('assert');
var url = 'mongodb://localhost:27017/testdb1';
exports.connection = function(collection, data){
	console.log(collection);
	MongoClient.connect(url, function(err, db) {
	assert.equal(null, err);
	console.log("Connected successfully to server");
	db.collection(collection).insert(data, function(err, records) {
	        if (err) throw err;
	        console.log("Record added as");
	    });
	  db.close();
	});
}
