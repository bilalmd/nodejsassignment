var db = require('../configuration/db');
var helper = require('../helper/helper');
var executor = require('../executor/executor');
var bodyParser = require('body-parser');
var moment = require('moment');
var fs = require('fs');

exports.executeSearchReq = function(req, res) {
    queryParams = req.query;
    var staticSearchReq = helper.searchRequest();
    var searchRequest = searchRequestDynamic(staticSearchReq, queryParams);
    //helper.logs("searchreq-"+logId(), JSON.stringify(searchRequest));
    db.connection('searchreq', searchRequest);
    executor.executeSearchReq(JSON.stringify(searchRequest), function(error, searchResponse) {
        if (error) {

            console.log(error)
        } else {
            //helper.logs("searchres-"+logId(), searchResponse);
            db.connection('searchres', JSON.parse(searchResponse));
        }
        var packages = JSON.parse(searchResponse);
        var packagesObj = JSON.parse(searchResponse);
        var packages = packagesObj.pkgSearchRS;
        //console.log(packages);
        res.render('results.ejs',{packages:packages})
    })

}
//HOTEL CHECKAVAILABILITY
exports.checkAvailability = function(req, res){
    var hotelId = req.query.hotelid;
    var availabilityRequest = helper.checkAvailability();
    var checkAvailability = checkAvailabilityObj(availabilityRequest, hotelId);
    //helper.logs('checkavailabilityReq'+logId(), JSON.stringify(availabilityRequest));
    db.connection('checkavailabilityReq', availabilityRequest);
    executor.checkAvailability(JSON.stringify(availabilityRequest), function(error, availabilityResponse){
        if(error){

            console.log(error)
        }else{
                helper.logs('checkavailabilityRes'+logId(), availabilityResponse);
                db.connection('checkavailabilityRes', JSON.parse(availabilityResponse));
                res.send(availabilityResponse);
        }
    })
}
//CHECK AVAILABILITY
function checkAvailabilityObj(availabilityRequest, hotelId) {
    fs.readFile("files/searchres-ssmpd.txt", "utf-8", function(error, data) {
        if (error) {
            console.log(error);
        } else {
            var hotelsData = JSON.parse(data);
            var allHotels = hotelsData.pkgSearchRS.pkgResults;
            var flight = hotelsData.pkgSearchRS.flightResults[0];
            var phinfo = availabilityRequest.pkgAvailabilityCheckRQ.phinfo;
            var pfinfo = availabilityRequest.pkgAvailabilityCheckRQ.pfinfo;
            var rooms = availabilityRequest.pkgAvailabilityCheckRQ.productRequestDetails.hotelAvailabilityRQ.BookingInfoRQ.hotel.rc.room;
            var ruleDetails = availabilityRequest.pkgAvailabilityCheckRQ.ruleDetails;
            //var flightAvailabilityRQ = availabilityRequest.pkgAvailabilityCheckRQ.flightAvailabilityRQ.fareruleRQ.aipi;
            for (var h = 0; h < allHotels.length; h++) {
                if (allHotels[h].hResult.photel[0].or.rc.ht.hid == hotelId) {
                    //hotel
                    phinfo = allHotels[h].hResult.photel[0].phinfo;
                    rooms =  allHotels[h].hResult.photel[0].or.rc;
                    ruleDetails = allHotels[h].ruleDetails;
                    //flight
                    pfinfo = allHotels[h].flightResults[0].pfinfo
                    //flightAvailabilityRQ = allHotels[h].flightResults[0].aipi
                }

            }
                return phinfo;
                return pfinfo;
                return rooms;
                return ruleDetails;
                //return flightAvailabilityRQ;
        }
    })
}


//DYNAMIC SEARCH REQUEST BUILDING
function searchRequestDynamic(staticSearchReq, queryParams) {

    var flightSearchRQ = staticSearchReq.pkgSearchRQ.productRequestDetails.flightSearchRQ;
    var hotelSearchRQ = staticSearchReq.pkgSearchRQ.productRequestDetails.hotelSearchRQ;
    var duration = moment(queryParams.checkOutDate, "YYYY/MM/DD").diff(moment(queryParams.checkInDate, "YYYY/MM/DD"));
    if (flightSearchRQ.searchRQ.tt == 2) {
        //FLIGHT REQUEST
        flightSearchRQ.searchRQ.odos.odo[0].dap = queryParams.departureDetails;
        flightSearchRQ.searchRQ.odos.odo[0].dd = queryParams.departureDate;
        flightSearchRQ.searchRQ.odos.odo[0].aap = queryParams.arriveDetails;
        flightSearchRQ.searchRQ.odos.odo[1].dap = queryParams.arriveDetails;
        flightSearchRQ.searchRQ.odos.odo[1].dd = queryParams.arrivalDate;
        flightSearchRQ.searchRQ.odos.odo[1].aap = queryParams.departureDetails;
        flightSearchRQ.searchRQ.ptq = ptq(queryParams);
        flightSearchRQ.searchRQ.ct = queryParams.classType;
        flightSearchRQ.searchRQ.tt = queryParams.tripType;
        //HOTEL REQUEST
        hotelSearchRQ.searchRQ.sc.ad = queryParams.departureDate;
        hotelSearchRQ.searchRQ.sc.dur = Math.round(moment.duration(duration).asDays());
        hotelSearchRQ.searchRQ.sc.cid = queryParams.predictiveId;
        hotelSearchRQ.searchRQ.sc.skm = true;
    } else if (flightSearchRQ.searchRQ.tt == 1) {
        flightSearchRQ.searchRQ.odos.odo[0].dap = queryParams.departureDetails;
        flightSearchRQ.searchRQ.odos.odo[0].dd = queryParams.departureDate;
        flightSearchRQ.searchRQ.odos.odo[0].aap = queryParams.arriveDetails;
        flightSearchRQ.searchRQ.ptq = ptq(queryParams);
        flightSearchRQ.searchRQ.ct = queryParams.classType;
        flightSearchRQ.searchRQ.tt = queryParams.tripType;
        //HOTEL REQUEST
        hotelSearchRQ.searchRQ.sc.ad = queryParams.arrivalDate;
        hotelSearchRQ.searchRQ.sc.dur = Math.round(moment.duration(duration).asDays());
        hotelSearchRQ.searchRQ.sc.cid = queryParams.predictiveId;
        hotelSearchRQ.searchRQ.sc.skm = true;
    }
    hotelSearchRQ.searchRQ.rms.rm = createRoomsDynamically(queryParams);

    //console.log(JSON.stringify(staticSearchReq));

    return staticSearchReq;
}
//CREATE ROOMS DYNAMICALLY

function createRoomsDynamically(queryParams) {
    var rooms = queryParams.noOfRooms;
    var Adults = queryParams.noOfAdults;
    var Child = queryParams.noOfChildren;
    var infants = queryParams.infantsArr;
    var ChildAge = queryParams.childrenAges;
    var roomObj = [];
    var pid = 1;
    for (var r = 0; r < rooms; r++) {
        var roomInfo = {
            na: Adults.split(',')[r],
            nc: Child.split(',')[r],
            pax: []
        }
        var totalPassenger = parseInt(roomInfo.na) + parseInt(roomInfo.nc);
        for (var tp = 0; tp < totalPassenger; tp++) {
            paxObj = {
                age: "45",
                id: pid
            }
            pid++;
            roomInfo.pax.push(paxObj);
        }
        roomObj.push(roomInfo);
    }

    return roomObj;
}
//SEARCH REQUEST ptq DYNAMIC
function ptq(queryParams) {
    var ptq = [{

        "ADT": queryParams.adult,
    }];
    if (queryParams.child != 0) {
        ptq.push({
            "CHD": queryParams.child,
        });
    }
    if (queryParams.infant != 0) {
        ptq.push({
            "INF": queryParams.infant,
        });
    }
    return ptq;
}
//LOGS DYNAMIC NAMES
function logId()
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));
        var logname = text+".txt";
    return logname;
}
